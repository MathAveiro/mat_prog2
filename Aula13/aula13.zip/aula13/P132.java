import static java.lang.System.*;
import java.util.Scanner;

public class P132
{
   public static void main(String[] args)
   {

   }
}

