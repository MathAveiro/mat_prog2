import static java.lang.System.*;
import java.io.*;
import java.util.Scanner;

public class P81
{
   public static void main(String[] args) throws IOException
   {
   }
}


