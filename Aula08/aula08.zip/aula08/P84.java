
import static java.lang.System.*;
import java.io.*;
import p2utils.*;

public class P84
{
   // teste das funções toString() e merge()
   public static void main(String[] args) throws IOException
   {
      SortedList<Integer> lst = new SortedList<Integer>();

      for(int i=0; i<args.length; i++) {
         lst.insert(Integer.parseInt(args[i]));
      }

      out.println(lst.toString());
      
      SortedList<Integer> lst2 = new SortedList<Integer>();
      lst2.insert(999);
      lst2.insert(99);
      lst2.insert(9);
      out.println(lst.merge(lst2).toString());
   }
}


