import static java.lang.System.*;
import java.util.Scanner;
import java.io.*;
import exameP2.*;

public class CityTraveler
{
}
