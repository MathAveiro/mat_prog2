

public class Door {

   public Door(int r1, int r2, double w, double h) {

   }

}

