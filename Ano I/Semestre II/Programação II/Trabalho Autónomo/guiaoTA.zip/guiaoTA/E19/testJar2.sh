#!/bin/bash

java -ea -jar Restaurante.jar food-data02.txt
