#!/bin/bash

java -ea Restaurante food-data01.txt
