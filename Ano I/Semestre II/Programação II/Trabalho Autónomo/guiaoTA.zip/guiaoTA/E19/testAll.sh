#!/bin/bash

java -ea Restaurante food-data*.txt
