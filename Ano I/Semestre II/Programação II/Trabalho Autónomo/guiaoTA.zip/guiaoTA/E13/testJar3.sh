#!/bin/bash

java -ea -jar P1.jar 2 3 3 3 out 3 3
