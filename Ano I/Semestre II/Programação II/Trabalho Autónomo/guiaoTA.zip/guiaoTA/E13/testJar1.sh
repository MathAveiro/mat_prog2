#!/bin/bash

java -ea -jar P1.jar 1 1 1 2 2 3 4 4
