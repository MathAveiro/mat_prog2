#!/bin/bash

java -ea -jar P1.jar 1 max min a
