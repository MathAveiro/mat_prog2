#!/bin/bash

java -ea P1 2 3 3 3 out 3 3
