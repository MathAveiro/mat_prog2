/**
 * Uma estrutura de dados baseada numa fila, mas em que só ficam
 * armazenados os últimos N números inseridos. Quando a fila está
 * preenchida (N elementos) a inserção de um novo número implica
 * a saída do primeiro (que deixa de existir).
 */

public class LeakyQueue
{
}

