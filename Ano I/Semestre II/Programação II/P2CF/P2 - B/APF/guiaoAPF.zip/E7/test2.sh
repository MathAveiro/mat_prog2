#!/bin/bash

java -ea Restaurante food-data02.txt
