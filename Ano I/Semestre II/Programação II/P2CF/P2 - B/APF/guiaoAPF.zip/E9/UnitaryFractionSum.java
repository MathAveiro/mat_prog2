import static java.lang.System.*;

public class UnitaryFractionSum
{
}

