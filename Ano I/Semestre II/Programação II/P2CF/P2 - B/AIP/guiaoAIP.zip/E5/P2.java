import static java.lang.System.*;

public class P2
{
   public static void main(String[] args)
   {
   }
}

