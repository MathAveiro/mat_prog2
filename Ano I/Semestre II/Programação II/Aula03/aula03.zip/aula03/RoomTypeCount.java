
public class RoomTypeCount {
   String roomType;
   int count;
}

