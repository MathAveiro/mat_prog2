Abra o ficheiro doc/index.html com um browser e siga as indicações.

Se não tiver esse directório ou ficheiro, pode gerá-lo correndo o comando:
  sh makeDoc

Ou se o seu sistema operativo não correr esse script, execute à mão o seu conteúdo:
  javadoc -private -charset UTF8 -author -linksource \
      -link http://java.sun.com/j2se/1.5.0/docs/api \
      -overview overview.html -d doc v*

