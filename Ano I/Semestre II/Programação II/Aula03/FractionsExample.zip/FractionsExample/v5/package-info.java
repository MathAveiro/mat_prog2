/**
 * Calculadora com fracções - Versão 5: Programa principal + Objectos
 * <P>
 * Introduz métodos de objecto (não {@code static}) e
 * protecção de dados {@code private/public} (information hiding).
 */
package v5;
