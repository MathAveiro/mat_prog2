/**
 * Calculadora com fracções - Versão 4:
 * Programa + Módulo tipo de dados com operações.
 */
package v4;

