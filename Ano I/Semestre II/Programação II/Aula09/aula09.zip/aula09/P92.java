import static java.lang.System.*;
import java.util.Scanner;

public class P92
{
   public static void main(String[] args)
   {
      NumberArray na = new NumberArray();
      insertionSort(na.array(), 0, na.length());
      na.print();
   }

   static void insertionSort(int[] array, int start, int end)
   {
   }
}

