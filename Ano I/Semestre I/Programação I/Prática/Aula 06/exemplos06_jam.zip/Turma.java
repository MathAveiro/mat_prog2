
import java.util.Scanner;
/*
* Created by jam on 26-out-2015
* Ler notas de 0 a 20 (terminar com valor negativo) e calcular media 
* arrays 2 dimensões: id aluno, mt1,mt2,tpi,ex
*/

public class Turma {

	public static void main(String[] args) {
		// Scanner para leitura de dados do teclado
		Scanner ler = new Scanner(System.in);
		final int NALUNOS = 10;
		int[][] turma= new int[NALUNOS][5];
		int id, soma=0, num=0;
		float media;
		System.out.println("Introduza as notas dos alunos (ID = 0 termina):");
		System.out.printf("ID do aluno: ");
		id = ler.nextInt();
		while (id > 0) {
			turma[num][0]=id;
			System.out.printf("Nota MT1:");
			turma[num][1] = ler.nextInt();
			System.out.printf("Nota MT2");
			turma[num][2] = ler.nextInt();
			System.out.printf("Nota TPI:");
			turma[num][3] = ler.nextInt();
			System.out.printf("Nota EXF:");
			turma[num][4] = ler.nextInt();
			num = num +1;
			System.out.printf("ID do aluno: ");
			id = ler.nextInt();
		}
		System.out.println("__ID_MT1_MT2_TPI_EXF");
		for (int a=0; a <num ; a++){
			for (int c=0;c<5;c++)System.out.printf("%4d",turma[a][c]);
			System.out.println();
		}
		System.out.printf("media col %2d = %f", 2,media(turma,2,num));
	}
	public static float media (int[][] tabela, int c, int nl){
		int soma=0;
		for (int n=0;n<nl;n++){
			soma = soma + tabela[n][c];
		}
		return (float)soma/nl;
	}
}
