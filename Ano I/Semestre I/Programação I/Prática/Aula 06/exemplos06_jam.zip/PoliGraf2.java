
import java.util.*;
import processing.core.*;

public class PoliGraf2 extends PApplet {

    float A, B, C; // coeficientes do polinómio 
    public void setup() {
        // size(200, 200);
        background(0);
        stroke(255, 0, 0); // vermelho
        line(0, 100, 200, 100); //eixo x
        line(100, 0, 100, 200); //eixo y
        stroke(255); // branco - niveis de cinzento
// Scanner para leitura de dados do teclado
        Scanner ler = new Scanner(System.in);
       
        float y, y0, x, x0; // 
        float delta = 0.1F;
        char raiz;
        // Ler coeficientes A; B; C
        System.out.print("Introduza os coeficientes A, B, C do polinomio:\n");
        A = ler.nextFloat();
        B = ler.nextFloat();
        C = ler.nextFloat();
        // cálculo 2 raizes reais usando fórmula resolvente
        x = -10.0F;
        y0 = A * x * x + B * x + C;
        for (int i = 0; i < 200; i++) {
            x0 = x;
            x = x + delta;
            y = A * x * x + B * x + C;
            raiz = ' ';
            if ((y0 > 0 && y <= 0) || (y0 < 0 && y >= 0)) {
                raiz = 'R';
            }
            // imprime resultado
            System.out.printf("x, y = %f, %f %c\n", x, y, raiz);
            // desenha gráfico
            line(10 * x0 + 100, 100 - y0, 10 * x + 100, 100 - y);
            y0 = y;
        }
    }

    public void settings() {
        size(200, 200);
    }

    public void draw() {
        stroke(255);
        if (mousePressed) {
            line(mouseX, mouseY, pmouseX, pmouseY);
        }
    }

    public static void main(String args[]) {
        PApplet.main(new String[]{"PoliGraf2"});
    }
}
