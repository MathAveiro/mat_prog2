
import java.util.*;
/*
 * Created by jam on 16-Jun-15.
 */

public class ForEach {

    public static void main(String[] args) {
        
        Random rand = new Random(47);
        float[] f = new float[10];
        char[] t;// = new char[100];
        for (int i = 0; i < 10; i++) {
            f[i] = rand.nextFloat();
        }
        for (float x : f) {
            System.out.println(x);
        
        }
        for(char c : "Aveiro tem moliceiros".toCharArray() )
            System.out.print(c + " ");
        System.out.printf("\n");
        // 
        t = "Aveiro tem moliceiros".toCharArray();
        for(char c : t )
            System.out.print(c + ".");
        System.out.printf("\n%d\n",t.length);
    }
}
