import java.util.Scanner;

// multiplicar todos os numeros introduzidos, termina com zero

public class exemplo4
{
  public static void main(String[] args)
  {        
    Scanner sc = new Scanner(System.in);
    
    int n;
    int cont = 0;
    int prod = 1; // ATENCAO!
    
    do
    {
		System.out.print("Valor: ");
		n = sc.nextInt();
		if(n != 0)
		{
			cont++;
			prod *= n; // prod = prod * n;
		}
    }while(n != 0);
    
	System.out.println("Fim do programa com a leitura de " + cont + " valores e resultado " + prod);
  }
}
