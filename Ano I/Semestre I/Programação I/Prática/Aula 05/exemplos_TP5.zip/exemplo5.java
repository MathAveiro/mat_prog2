import java.util.Scanner;

// Calcular a media dos numeros introduzidos
// termina com a introdução de um numero dobro do anterior

public class exemplo5
{
  public static void main(String[] args)
  {        
    Scanner sc = new Scanner(System.in);
    int n = 0, soma = 0, ant, cont = 0;
    double media;
    
    do{
		ant = n;
		
		do
		{
			System.out.print("Valor: ");
			n = sc.nextInt();
		}while(n <= 0);
				
		soma += n;
		cont++;
	}while(n != 2 * ant);
	
	media = (double)soma / cont;
	
	System.out.println("Media = " + media);
	}
}
