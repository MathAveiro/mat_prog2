import java.util.Scanner;

// Operadores de incremento e decremento
// operação de atribuicao com operacao

public class exemplo1
{
  public static void main(String[] args)
  {        
    Scanner sc = new Scanner(System.in);
    
    int a = 0;
    
    System.out.println(a);
    a++;
    System.out.println(a);
    a--;
    System.out.println(a);
    
    int b = a++;
    System.out.println("b = " + b + " a = " + a);
    
    a = 0;
    b = ++a;
    System.out.println("b = " + b + " a = " + a);
    
    b = 0;
    
    b += 10;
    System.out.println("b = " + b);
  }
}
