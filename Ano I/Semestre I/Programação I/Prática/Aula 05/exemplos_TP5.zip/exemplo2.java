import java.util.Scanner;

// leitura de numeros ate aparecer zero e contagem dos numeros introduzidos
// solucao com while

public class exemplo2
{
  public static void main(String[] args)
  {        
    Scanner sc = new Scanner(System.in);
    
    int n;
    int cont = 0;
    
    System.out.print("Valor (primeiro): ");
    n = sc.nextInt();
    while(n != 0)
    {
		cont++;
		System.out.print("Valor: ");
		n = sc.nextInt();		
	}
	System.out.println("Fim do programa com a leitura de " + cont + " valores");
  }
}
