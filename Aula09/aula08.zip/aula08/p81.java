import static java.lang.System.*;
import java.util.Scanner;

public class p81
{
   public static void main(String[] args)
   {
      NumberArray na = new NumberArray();
      mergeSort(na.array(), 0, na.length());
      na.print();
   }

   static void mergeSort(int[] array, int start, int end)
   {
   }
}

